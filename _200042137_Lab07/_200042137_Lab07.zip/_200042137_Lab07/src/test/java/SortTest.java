import org.junit.Assert;
import org.junit.jupiter.api.Test;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;

public class SortTest {
  static WebDriver driver;

  @BeforeAll
    public static void beforeall()
  {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\lenovo\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        ChromeOptions options=new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
    driver=new ChromeDriver(options);
    }
  @AfterAll
    public static void afterall(){
    driver.close();
    }


  @Test
  public void sortAtoZ() {
      driver.get("https://practicesoftwaretesting.com/#");
      WebElement dropdown = driver.findElement(By.cssSelector("[data-test='sort']"));

      Select select = new Select(dropdown);

      select.selectByValue("name,asc");

      try {
          Thread.sleep(5000); // Replace with a more robust waiting mechanism (e.g., waiting for element visibility)
      } catch (InterruptedException e) {
          e.printStackTrace();
      }

      List<String> actualProductNames = new ArrayList<>();

      List<WebElement> productCards = driver.findElements(By.cssSelector(".card-body")); // Modify locator as needed

      for (WebElement productCard : productCards) {
          String productName = productCard.findElement(By.cssSelector("h5[data-test='product-name']")).getText();
          System.out.println(productName);
          actualProductNames.add(productName);

      }
      for (int i = 0; i < actualProductNames.size() - 1; i++) {
        if (actualProductNames.get(i).compareToIgnoreCase(actualProductNames.get(i + 1)) > 0) {
          throw new AssertionError("Product names are not sorted in ascending order");
        }
      }

    }
    @Test
    public void sortZtoA() {
        driver.get("https://practicesoftwaretesting.com/#");
        WebElement dropdown = driver.findElement(By.cssSelector("[data-test='sort']"));

        Select select = new Select(dropdown);

        select.selectByValue("name,desc");

        try {
            Thread.sleep(5000); // Replace with a more robust waiting mechanism (e.g., waiting for element visibility)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<String> actualProductNames = new ArrayList<>();

        List<WebElement> productCards = driver.findElements(By.cssSelector(".card-body")); // Modify locator as needed

        for (WebElement productCard : productCards) {
            String productName = productCard.findElement(By.cssSelector("h5[data-test='product-name']")).getText();
            System.out.println(productName);
            actualProductNames.add(productName);

        }
        for (int i = 0; i < actualProductNames.size() - 1; i++) {
            if (actualProductNames.get(i).compareToIgnoreCase(actualProductNames.get(i + 1)) < 0) {
                throw new AssertionError("Product names are not sorted in ascending order");
            }
        }

    }

    @Test // Assuming you're using TestNG for tests
    public void SortByPriceHighToLow() throws Exception {
        driver.get("https://practicesoftwaretesting.com/#");
        WebElement dropdown = driver.findElement(By.cssSelector("[data-test='sort']"));

        Select select = new Select(dropdown);
        select.selectByValue("price,desc");

        // Wait for the page to reload after sorting (adjust timeout if needed)
        try {
            Thread.sleep(5000); // Replace with a more robust waiting mechanism (e.g., waiting for element visibility)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // List to store extracted product prices (assuming prices are numbers)
        List<Double> actualPrices = new ArrayList<>();

        // Find all product card elements (replace with appropriate locators for your site)
        List<WebElement> productCards = driver.findElements(By.cssSelector(".product-card")); // Modify locator as needed

        // Extract product prices from each card and add them to the actual list (assuming price element has a specific class or ID)
        for (WebElement productCard : productCards) {
            String priceString = productCard.findElement(By.cssSelector(".product-price")).getText(); // Modify locator as needed
            double price = Double.parseDouble(priceString); // Parse string to double
            actualPrices.add(price);
        }

        // Verify if product prices are sorted in descending order
        for (int i = 0; i < actualPrices.size() - 1; i++) {
            if (actualPrices.get(i) < actualPrices.get(i + 1)) {
                throw new AssertionError("Product prices are not sorted in descending order");
            }
        }
        // Close the browser
    }

    @Test
    public void SortByPriceLowtoHigh() throws Exception {
        driver.get("https://practicesoftwaretesting.com/#");
        WebElement dropdown = driver.findElement(By.cssSelector("[data-test='sort']"));

        Select select = new Select(dropdown);
        select.selectByValue("price,asc");

        // Wait for the page to reload after sorting (adjust timeout if needed)
        try {
            Thread.sleep(5000); // Replace with a more robust waiting mechanism (e.g., waiting for element visibility)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // List to store extracted product prices (assuming prices are numbers)
        List<Double> actualPrices = new ArrayList<>();

        // Find all product card elements (replace with appropriate locators for your site)
        List<WebElement> productCards = driver.findElements(By.cssSelector(".product-card")); // Modify locator as needed

        // Extract product prices from each card and add them to the actual list (assuming price element has a specific class or ID)
        for (WebElement productCard : productCards) {
            String priceString = productCard.findElement(By.cssSelector(".product-price")).getText(); // Modify locator as needed
            double price = Double.parseDouble(priceString); // Parse string to double
            actualPrices.add(price);
        }

        // Verify if product prices are sorted in descending order
        for (int i = 0; i < actualPrices.size() - 1; i++) {
            if (actualPrices.get(i) > actualPrices.get(i + 1)) {
                throw new AssertionError("Product prices are not sorted in ascending order");
            }
        }
        // Close the browser
    }



}

